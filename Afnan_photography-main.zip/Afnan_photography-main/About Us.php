<html>
    
    <head>
        <meta charset="utf-8">
        <link rel="shortcut icon"  href="Images/LB_Editedb.png">
        <link rel="stylesheet" type="text/css" href="About_us.css">
        <title>About Afnan</title>
    
    </head>
    
    <body>
       <?php include "Main_Nav.php"?>
        
        <div class="team-section">
            <br><h2>Our Photography</h2><br>
            <p>Click on the photo to Know more about Afnan</p>
            <span class="border"></span>
        <div class="ps">
            <a href="#p1"><img src="images/icon.jpg" alt="Afnan"></a>  
        </div>
         <div class = "section" id = "p1">
            <span class ="name"> Afnan Mohamed Mahmoud Gharid </span>
             <span class ="border"> </span>
             <p>
              <h2>The Greatest places that I worked in:</h2>
              <br>
                 <h4>.Police Mosque<br><br>
                 .The Castle<br><br>
                 .Tobio Maadi<br><br>
                 .Al Azhar Park<br><br>
                 .Camp Ismailia<br><br>
                 .January 25 Ismailia</h4>
              <h2>Years of experience : 2 years</h2>
              <br><br>
              <h2>The Greatest places that I worked in:</h2>
              <br>
                 <h4>
                 .Benha<br><br>
                 .Ash Sharqia<br><br>
                 .Ismailia<br><br>
                 .Cairo<br><br>
                 .Port Said<br><br>
                  </h4>
             </p>
            </div>    
        </div>       
    </body>
</html>