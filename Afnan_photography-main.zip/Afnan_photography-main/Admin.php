
<html >
<head>
	<link rel="stylesheet" type="text/css" href="Admin.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>

<body >
	<input type="checkbox" id="check">
<!--header begin-->
	<header style = 'margin-top: 0px;'>
		<label for="check">
			<i class="fas fa-bars" id="sidebar_btn"></i>
		</label>
        <div>
        <center>
		

  		</center>
        </div>
		<div class="right_area" style = 'margin-top: -15px;'>
     
            
            <div class ="logout">
          <a href="" class="fas fa-sign-out-alt" style = "margin-top:-100px;">Logout</a>
            </div>
            </div>
		<!--header end-->
	</header>
	<div class="sidebar" style = 'margin-top: 0px;'>
		<a href="AddAdmin.php"><i class="fas fa-plus-circle"></i><span>Add Admin</span></a>
        <a href=""><i class="fas fa-edit"></i><span>Edit HomePage</span></a>
        <a href="View%20Profile.php"><i class="fas fa-cog"></i><span>Edit Profile</span></a> 
            
        <a href=""><i class="fas fa-plus-circle"></i><span>Add Album</span></a>
        <a href=""><i class="fas fa-plus-circle"></i><span>Add Gallery</span></a>
        <a href=""><i class="fas fa-plus-circle"></i><span>Add Images</span></a>

          <a href=""><i class="fas fa-sign-out-alt"></i><span>Reservations</span></a>
		<a href="stat2.php"><i class="fas fa-chart-bar"></i><span>Statistics</span></a>

        <a href=""><i class="fas fa-sign-out-alt"></i><span>log out</span></a>
        
                
    
	</div>

</body>
</html>